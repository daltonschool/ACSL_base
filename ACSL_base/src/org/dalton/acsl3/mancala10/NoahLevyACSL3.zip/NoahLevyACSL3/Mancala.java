import java.util.Scanner;
/* Dalton
 * School Code: 9170
 * Noah Levy
 * ACSL III 2010-2011
 */
public class Mancala {

	private static final boolean debug = false;
	private static Oval ovals[] = new Oval[14];
	public static void main(String[]args)
	{

		initBoard();
		if(debug)System.out.println("Hello and Welcome to ACSL3 go:");
		for(int c = 1; c <= 5; c++)
		{
			runEms(c);
			if(debug)
			{
				System.out.println("------------------");
			}
		}
	}
	private static void runEms(int counter)
	{
		Scanner scan = new Scanner(System.in);
		String ginormostring = scan.nextLine();
		//ginormostring.replace(" ", "");
		String[] elems = new String[2];
		elems = ginormostring.split(", ");
		elems[0].trim();
		elems[1].trim();
		if(debug) System.out.println("Array says " + elems[0] + "," + elems[1]);
		Specialiaty team = chooseTeam(counter);
		int startspot = adjustNumbers(elems[0]);
		int investigatehere = adjustNumbers(elems[1]);

		if(debug)System.out.println("startspot" + startspot + " team" + team + " investigatehere" + investigatehere);
		if(ovals[startspot].getPennies() == 0)
		{
			System.out.println(ovals[investigatehere].getPennies());
		}
		else
		{
		System.out.println(runAround(startspot, team, investigatehere));
		}

	}
	private static Specialiaty chooseTeam(int input)
	{
		if((input % 2) != 0)
		{
			return Specialiaty.A;	
		}
		return Specialiaty.B;
	}
	private static int adjustNumbers(String input)
	{
		int num;
		int answer;

		if(input.contains("A"))
		{
			answer = 6;
		}
		else if(input.contains("B"))
		{
			answer = 13;
		}
		else
		{
			num = Integer.parseInt(input);

			if(num >= 1 && num <= 6)
			{

				answer = num - 1;
			}
			else
			{
				answer = num;
			}
		}
		return answer;
	}
	private static String indexToHuman(int i)
	{
		String ans = "";
		if(i == 6)
		{
			ans = "A";
		}
		else if(i == 13)
		{
			ans = "B";
		}
		else if(i == 14)
		{
			ans = "ROLLOVER INDEX";
		}
		else if(i >= 0 && i <= 5)
		{
			ans = Integer.toString((i + 1));
		}
		else
		{
			ans = Integer.toString(i);
		}
		return ans;
	}
	private static int runAround(int index, Specialiaty team, int target)
	{


		int pennies = ovals[index].getPennies();
		ovals[index].setPennies(0);
		if(debug)
		{
			System.out.println("starting humanindex is: " + indexToHuman(index));
		}
		//index++;
		for(int curp = pennies; curp > 0;)
		{
			index++;	
			if(index == 14)
			{
				index = 0;
				ovals[index].incrementPennies();
				curp--;
				if(debug)
				{
					System.out.println("rollover");
				}
			}
			else if((index == 6) && (team == Specialiaty.B))
			{
				if(debug)
				{
					System.out.println("I went over the wrong hole so i tried to skip");
				}
			}
			else if((index == 13) && (team == Specialiaty.A))
			{
				if(debug)
				{
					System.out.println("I went over the wrong hole so i tried to skip");
				}

			}
			else
			{
				ovals[index].incrementPennies();
				curp--;
			}
			if(debug)
			{
				System.out.println("current humanindex is:" + indexToHuman(index) + " and postvalue is:" + ovals[index].getPennies());
			}


			//if(debug)System.out.println("")
		}

		/*
		 * if((index == 6) || (index == 13) || (ovals[index].getPennies() == 4) || (ovals[index].getPennies() == 1))
		{
			return ovals[target].getPennies();
		}
		 */
		if(index == 6)
		{
			if(debug)
			{
				System.out.println("Escape because I landed in box A index = " + index);
			}
			return ovals[target].getPennies();
		}
		else if(index == 13)
		{
			if(debug)
			{
				System.out.println("Escape because I landed in box B index = " + index);
			}
			return ovals[target].getPennies();
		}
		else if(ovals[index].getPennies() == 4)
		{
			if(debug)
			{
				System.out.println("Escape because final pennies at humanindex " + indexToHuman(index) +" = " + ovals[index].getPennies());
			}
			return ovals[target].getPennies();
		}
		else if(ovals[index].getPennies() == 1)
		{
			if(debug)
			{
				System.out.println("Escape because final pennies at " + indexToHuman(index) +" = " + ovals[index].getPennies());
			}
			return ovals[target].getPennies();
		}
		else
		{
			if(debug)
			{
				System.out.println("new cycle");
			}
			return runAround(index, team, target);
		}

	}
	private static void initBoard()
	{

		for(int i = 0; i < ovals.length; i++)
		{
			ovals[i] = new Oval();
			if(i == 6)
			{
				ovals[i].setAll(0, Specialiaty.A);
			}
			if(i == 13)
			{
				ovals[i].setAll(0, Specialiaty.B);
			}			
		}

	}
}
