package mancala;
import java.util.ArrayList;
public class Board {
	ArrayList<Bucket> boar = new ArrayList<Bucket>(14); //A - 13 B - 0
	/**
	 * This class sets up the board by filling the ArrayList of Buckets where holes 1-12 are in positions 1-12, 
	 * the A hole is in position 13 and the B hole is in position 0. 
	 */
	public Board(){
		for(int i = 0; i<14; i++){
			boar.add(i, new Bucket(i));
		}
	}
	public void moveA(int hole){
		int ct = 0;
		boolean turn = true;
		while (turn){
			int st = boar.get(hole).takeStones();
			//System.out.println("took " + st + " stones from " + hole);
			int sp = hole+1;
			if (sp == 13) sp = 1;
			for(int i = 0; i<st; i++){
				if (i == 0 && sp == 7){
					sp = 13;
					boar.get(sp).addStone();
					//System.out.println("1 stone in " + sp);
					i++;
					if (i == st-1){
						//System.out.println("Reason for escape: landed in A");
						turn = false;
					}//if
					sp = 7;
				}//if
				boar.get(sp).addStone();
				//System.out.println("1 stone in " + sp);
				if(i == st - 1){
					if(boar.get(sp).getStones() == 4){ 
						//System.out.println("Reason for escape: 4 now in " + sp);	
						turn = false;
					}
					if(boar.get(sp).getStones() == 1) {
						//System.out.println("Reason for escape: was empty in " + sp);
						turn = false;
					}
				}//if
				if((sp == 6 && i < st-1)){
					sp = 13;
					boar.get(sp).addStone();
					//System.out.println("1 stone in " + sp);
					i++;
					if (i == st-1){
						turn = false;
						//System.out.println("Reason for escape: landed in A");
					}
					sp = 6;
				}
				if(sp == 12 && i<st-1){
					sp = 0;
				}
				sp++;
			}//for
			hole = sp - 1;
			//System.out.println("Turn count: " + ct);
			ct++;
		}//while
	}//moveA
	public void moveB(int hole){
		int ct = 0;
		boolean turn = true;
		while (turn){
			int st = boar.get(hole).takeStones();
			//System.out.println("took " + st + " stones from " + hole);
			int sp = hole+1;
			if(sp == 13){
				sp = 0;
			}//if
			for(int i = 0; i<st; i++){
				boar.get(sp).addStone();
				//System.out.println("1 stone in " + sp);
				if(i == st - 1){
					if(boar.get(sp).getStones() == 4){ 
						turn = false;
						//System.out.println("Reason for escape: 4 now in " + sp);	
					}
					if(boar.get(sp).getStones() == 1) {
						turn = false;
						//System.out.println("Reason for escape: was empty in " + sp);
					}
				}//if
				if(sp == 12 && i < st-1){
					sp = 0;
					boar.get(sp).addStone();
					//System.out.println("1 stone in " + sp);
					i++;
					if (i == st-1){
						turn = false;
						//System.out.println("Reason for escape: landed in A");
					}//if
				}//if
				sp++;
			}//for
			if (sp > 0)hole = sp - 1;
			else if (sp == 0) hole = 12;
			//System.out.println("Turn count: " + ct);
			ct++;
		}//while
	}
	public int print(String hole){
		int numstones = 0;
		if (hole.equals("B")) numstones = boar.get(0).getStones();
		else if (hole.equals("A")) numstones = boar.get(13).getStones();
		else numstones = boar.get(Integer.parseInt(hole)).getStones();
		return numstones;
	}//print
}//class