package acsl.ACSL4;
import java.util.ArrayList;
import java.util.Scanner;
public class ACSL4Test {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		for (int x = 0; x<5; x++)
		{
			boolean encode = false;
			ArrayList<Matrix> cypher = new ArrayList<Matrix>();
			String in = input.nextLine(); //take the input
			String[] data = in.split(", ");//split on the comma-space!

			if (data[0].equals("E")) encode = true; //encode or decode? decides here.
			else encode = false;
			
			String[] encoding = new String[]{data[2], data[3], data[4], data[5]};
			
			Matrix encodingMatrix = new Matrix(arrayToInts(encoding)); //split the given encoding matrix
			cypher = createLetterMatrices(data[1]);
			
			//System.out.println(cypher.toString());

			if (!encode) //if i have to decode the string - encodingMatrix has to be inversed.
			{
				encodingMatrix = encodingMatrix.getInverse(); //inverts the given encoding matrix for multiplication
			}	
			for (int z = 0;z< cypher.size();z++)
			{
				cypher.set(z, cypher.get(z).multiply(encodingMatrix)); //multiplies the matrices with the ecoding matrix
			}
			String toPrint="";
			for(int z = 0; z<cypher.size();z++)
			{
				toPrint = toPrint + cypher.get(z).toString(); //builds the print string
			}
			System.out.println(toPrint);
		}
	}
	
	public static int[] arrayToInts(String x[]) //converts the given string array into an array of ints
	{	
		int[] z = new int[x.length];
		for(int i = 0; i<x.length;i++)
		{
			z[i]=Integer.parseInt(x[i]);
		}
		return z;
	}
	
	public static ArrayList<Matrix> createLetterMatrices(String input) //creates an ArrayList of matrices to store the paris of letters
	{
		if (input.length()%2 ==1) input = input + " "; //add on a space to fill the odd spot in the matrix to prevent OutOfBounds
		ArrayList<Matrix> toCode = new ArrayList<Matrix>();
		for (int i=0;i<input.length();i=i+2)
		{
			toCode.add(new Matrix(input.substring(i, i+2)));//gets pairs of letters from the original string
		}
		return toCode;
	}
}
