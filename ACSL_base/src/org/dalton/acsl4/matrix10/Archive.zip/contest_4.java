package contest;
import java.util.Scanner;
import contest.letterConvert;
public class contest_4 {

/**
 * Rebecca Panovka
 * ACSL Contest #4
 * 
 */


	public static void main(String[] args) {
		for (int j= 1; j<6; j++)
		{
			System.out.println(j + ". ");
			Scanner in= new Scanner(System.in);
			String input= in.nextLine();
			char[] all_input= input.toCharArray();
			if (all_input[0]== 'E')
			{
				int count= 3;
				int number_of_characters = 0;
				char[] message_to_encode= new char[all_input.length];

				while (!(all_input[count] == ','))
				{
					message_to_encode[count-3]= all_input[count];
					count++;
					number_of_characters++;
				}
				int x = 3 + number_of_characters;
				int y = all_input.length- x;
				char[] encoding_matrix= new char[y];
				while (x< all_input.length)
				{
					encoding_matrix[x - 3 - number_of_characters]= all_input[x];
					x++;
				}
				String str = new String(encoding_matrix);
				String str1 = str.replace(',', ' ');
				String[] arr = str1.split("  ");
				int intarray[] = new int[arr.length];

				for (int i = 1; i < arr.length; i++) 
				{
					intarray[i] = Integer.parseInt(arr[i]);
				}


				if ((number_of_characters % 2) == 1)
				{
					number_of_characters ++; 
					message_to_encode[number_of_characters] = ' ';
				}
				int n=0;
				String encoded= j + ". ";
				while (n <= number_of_characters -2)
				{
					letterConvert first_letter = new letterConvert(); 	
					letterConvert second_letter = new letterConvert();
					double top= first_letter.encodeLetter(message_to_encode[n]);
					double bottom= second_letter.encodeLetter(message_to_encode[n+1]);
					double top_code = (intarray[1] * top) +  (intarray[2] * bottom);
					double bottom_code = (intarray[3] * top) +  (intarray[4] * bottom);
					letterConvert first_number = new letterConvert();
					letterConvert second_number = new letterConvert();
					char letter1= first_number.encodeNumber(top_code);
					char letter2= second_number.encodeNumber(bottom_code);
					encoded= encoded + letter1 + letter2;
					n= n+2;
				}
				System.out.println(encoded);
			}
			if (all_input[0]== 'D')
			{

				int count= 3;
				int number_of_characters = 0;
				char[] message_to_decode= new char[all_input.length];

				while (!(all_input[count] == ','))
				{
					message_to_decode[count-3]= all_input[count];
					count++;
					number_of_characters++;
				}
				
				int x = 3 + number_of_characters;
				int y = all_input.length- x;
				char[] decoding_matrix= new char[y];
				while (x< all_input.length)
				{
					decoding_matrix[x - 3 - number_of_characters]= all_input[x];
					x++;
				}
				String str = new String(decoding_matrix);
				String str1 = str.replace(',', ' ');
				String[] arr = str1.split("  ");
				int intarray[] = new int[arr.length];

				for (int i = 1; i < arr.length; i++) 
				{
					intarray[i] = Integer.parseInt(arr[i]);
				}
				if ((number_of_characters % 2) == 1)
				{
					number_of_characters ++; 
					message_to_decode[number_of_characters] = ' ';
				}
				
				int n=0;
				String decoded= j + ". ";
				letterConvert a = new letterConvert();
				letterConvert b = new letterConvert();
				letterConvert c = new letterConvert();
				letterConvert d = new letterConvert();
				double inverse_1 = a.invertA(intarray[1], intarray[2], intarray[3], intarray[4]);
				double inverse_2 = b.invertB(intarray[1], intarray[2], intarray[3], intarray[4]);
				double inverse_3 = c.invertC(intarray[1], intarray[2], intarray[3], intarray[4]);
				double inverse_4 = d.invertD(intarray[1], intarray[2], intarray[3], intarray[4]);
				while (n <= number_of_characters -2)
				{
					
					letterConvert first_letter = new letterConvert(); 	
					letterConvert second_letter = new letterConvert(); 	
					double top= first_letter.encodeLetter(message_to_decode[n]);
					double bottom= second_letter.encodeLetter(message_to_decode[n+1]);
					double top_code = (inverse_1 * top) +  (inverse_2 * bottom);
					double bottom_code = (inverse_3 * top) +  (inverse_4 * bottom);

					
					letterConvert first_number = new letterConvert();
					letterConvert second_number = new letterConvert();
					char letter1= first_number.encodeNumber(top_code);
					char letter2= second_number.encodeNumber(bottom_code);				
					decoded= decoded + letter1 + letter2;
					n= n+2;
					
				}
				System.out.println(decoded);
				
			}
		}
	}
}


