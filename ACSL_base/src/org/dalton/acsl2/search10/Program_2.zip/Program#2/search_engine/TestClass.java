package search_engine;
import java.util.Scanner;
public class TestClass {
	public static void main(String[] args){
		SearchEngine se = new SearchEngine();
		Scanner input = new Scanner(System.in);
		String in = "";
		String[]inp;
		
		System.out.print("1.");
		in = input.nextLine();
		inp = in.split(", ");
		inp[inp.length-1] = inp[inp.length-1].substring(0, inp[inp.length-1].length());
		for(int i=0; i<inp.length; i++){
			se.setInput(i, inp[i]);
		}
		for(int i = 1; i<6; i++){
			System.out.print(i+1 + ". ");
			System.out.println(se.check(input.nextLine()));
			
		}
	}
}
