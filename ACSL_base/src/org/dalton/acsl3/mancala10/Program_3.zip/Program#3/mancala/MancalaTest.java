package mancala;
import java.util.Scanner;
public class MancalaTest {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		Board b = new Board();
		System.out.print("1.");
		String At_1 = input.nextLine();
		int m1A = Integer.parseInt(At_1.substring(0, At_1.lastIndexOf(",")));
		String p1A = At_1.substring(At_1.lastIndexOf(", ") + 2, At_1.length());
		b.moveA(m1A);
		System.out.println("1. " + b.print(p1A));

		System.out.print("2.");
		String Bt_2 = input.nextLine();
		int m2B = Integer.parseInt(Bt_2.substring(0, Bt_2.lastIndexOf(",")));
		String p2B = Bt_2.substring(Bt_2.lastIndexOf(", ") + 2, Bt_2.length());
		b.moveB(m2B);
		System.out.println("2. " + b.print(p2B));

		System.out.print("3.");
		String At_3 = input.nextLine();
		int m3A = Integer.parseInt(At_3.substring(0, At_3.lastIndexOf(",")));
		String p3A = At_3.substring(At_3.lastIndexOf(", ") + 2, At_3.length());
		b.moveA(m3A);
		System.out.println("3. " + b.print(p3A));

		System.out.print("4.");
		String Bt_4 = input.nextLine();
		int m4B = Integer.parseInt(Bt_4.substring(0, Bt_4.lastIndexOf(",")));
		String p4A = Bt_4.substring(Bt_4.lastIndexOf(", ") + 2, Bt_4.length());
		b.moveB(m4B);
		System.out.println("4. " + b.print(p4A));

		System.out.print("5.");
		String At_5 = input.nextLine();
		int m5A = Integer.parseInt(At_5.substring(0, At_5.lastIndexOf(",")));
		String p5A = At_5.substring(At_5.lastIndexOf(", ") + 2, At_5.length());
		b.moveA(m5A);
		System.out.println("5. " + b.print(p5A));
	}//main
}//class
