import java.util.Scanner;
public class ACSL3 {
	/**Kristin Kury
	 * ACSL 3
	 * 9072
	 * The Dalton School 
	 */
	public static void main(String[] args)
	{
		int user = 0; //this variable will be incremented and determine if user is A or B
		Scanner scan = new Scanner(System.in); //new scanner
		int[] board;              // create the board
		board = new int[12];      // create 12 pods (the mancalas for A and B are separate)
		//set each of the pods to have 4 beads 
		board[0] = 4;
		board[1] = 4;
		board[2] = 4;
		board[3] = 4;
		board[4] = 4;
		board[5] = 4;
		board[6] = 4;
		board[7] = 4;
		board[8] = 4;
		board[9] = 4;
		board[10] = 4;
		board[11] = 4;
		int mancalaB = 0; 
		int mancalaA = 0; //create the two mancalas
		for(int i = 0; i < 5; i++) //run program 5 times
		{			
			String userinput = scan.nextLine(); //take in user input
			String[] inputarray = userinput.split(", "); //split into two things, 1st is starting point 2nd is other thing
			int currentpos = Integer.parseInt(inputarray[0]) -1; //starting point is part 1, easier to read
			boolean A_is_output = false;
			boolean B_is_output = false;
			int output = 0;
			if(inputarray[1].equals("A"))
			{
				//	System.out.println("output will be A");
				A_is_output = true;
			}

			else if(inputarray[1].equals("B"))
			{
				B_is_output = true;
			}

			else
			{
				//System.out.println("lol output won't be A");
				output = Integer.parseInt(inputarray[1]) -1 ; //output location is part 2
			}			
			int inhand = 0; //what the user has in hand
			boolean user_is_A; //create a boolean, determine if player is A or B

			if(user%2 == 0) //if user is even, you are player A
			{
				user_is_A = true;
			}
			else
			{
				user_is_A = false;
			}
			inhand = board[currentpos]; //the user has what was in the starting point in hand
			board[currentpos] = 0; //empty starting point
			
			
			if(currentpos < 11)
			{
			currentpos++;
			}
			
			else if(currentpos ==11)
			{
				currentpos =0;
			}

			boolean isayso = true;
			while(isayso) //put a thing in the each pod until in hand is empty
			{
				while(inhand > 0) //keep doing this as long as inhand is greater than zero
				{
					board[currentpos] = board[currentpos] + 1; //add one to current pod
					inhand = inhand - 1; //subtract a bead from the current hand
				//	System.out.println("pod " + (currentpos + 1) + " has " + board[currentpos] + " beads. there are " + inhand + " left in hand");


					if((board[currentpos] == 4 || board[currentpos] == 1) && inhand == 0) //if you put your last bead in a pod and it equals 4, or if it equals one
					{
						if(A_is_output)
						{
							System.out.println(mancalaA);
						}

						else if(B_is_output)
						{
							System.out.println(mancalaB);
						}

						else
						{
							System.out.println(board[output]);
						}
						//System.out.println("101 turn is over");
						isayso = false;
					}


					if(currentpos == 11) //if you're right in front of B's mancala
					{
					/*	if(user_is_A) //if user is A, just keep moving
						{
							currentpos = 0;	
							System.out.println("78");
						}*/
						if(!user_is_A) //if the user is B, do shit to mancala
						{
							if(inhand > 0)
							{
								inhand--; //remove additional bead from hand
							}

							else
							{
								inhand = board[11] - 1; //put into hand, take one out (go into mancala)
								board[11] = 0;

							//	System.out.println("B took beads from 12. pod 12 has" + board[11]);
							}
							mancalaB++; //anadd a bead to B's mancala
							//System.out.println("B put a bead into mancala. mancala has" + mancalaB + " beads." + inhand + " beads in hand"); 

							if(inhand == 0) //if the hand is empty after putting bead in mancala
							{
								if(A_is_output)
								{
									System.out.println(mancalaA); 
								}

								else if(B_is_output)
								{
									System.out.println(mancalaB);
								}

								else
								{
									System.out.println(board[output]);
								}

								//System.out.println("148 turn is over!");
								isayso = false;
							}
						}
					}//if you are at pod 12 (right before B's mancala)

					if(user_is_A && currentpos == 5)//if user A is abot to put a thing in the mancala
					{
						//board[currentpos] = board[currentpos] + 1; //add bead to thing
					//	inhand--; //remove one from hand
						//System.out.println("149 pod " + (currentpos + 1) + " has " + board[currentpos] + " beads. there are " + inhand + " left in hand");

						if(inhand > 0)
						{
							inhand--; //remove additional thing from bead
						}

						else
						{
							inhand = board[5] - 1; //take the beads from pod 5, and subtract 1 (will go in mancala)
							board[5] = 0;
						//	System.out.println("A took the beads from pod 6. pod 6 has " + board[5] + " beads. there are " +inhand+ " beads in hand because");
						}

						mancalaA++; //add one thing to user A's mancala
					//	System.out.println("A put a bead into mancala. mancala has" + mancalaA + " beads." + inhand + " beads left in hand");
						
						if(inhand == 0) //if you are right before mancala, and hand is empty
						{
							if(A_is_output)
							{
								System.out.println(mancalaA);
							}

							else if(B_is_output)
							{
								System.out.println(mancalaB);

							}

							else
							{
								System.out.println(board[output]);

							}
							//System.out.println("191 turn is over!");
							isayso = false;
						}

						
					}//if you are user A, and you are right infront of your mancala
					//}//if the turn didn't end because pod = 4 or 1

					if(inhand == 0 && isayso)
					{
					//	System.out.println("195");
						//if(currentpos > 0) //
						{

							inhand = board[currentpos]; //take the beads from the last position

							board[currentpos] = 0;
							//issue here
						//	System.out.println("user takes beads from pod " +(currentpos+1)+ ". user has " +inhand+"beads in hand. pod " +(currentpos+1) + " has " +board[currentpos]);
						}

						/*else//if at pod 1
						{
							inhand = board[11]; //take bead from pod 12
							board[11] = 0;
							System.out.println("user takes beads from pod 12. pod 12 has" + board[11] + " beads");

						}*/
					}
					if(currentpos < 11)
					{
					currentpos++;
					}
					
					else if(currentpos ==11)
					{
						currentpos =0;
					}
				}//closes while in hand > 0 (gets here, checks "is hand empty?" if not, repeats
			}//while isayso (when the turn ends)
			user++; //increment user by 1 so that the current player will change
			isayso = true;
		}//closes for loop (it gets here, adds 1 to i, goes back to beginning -> i
	}//closes main
}//closes class