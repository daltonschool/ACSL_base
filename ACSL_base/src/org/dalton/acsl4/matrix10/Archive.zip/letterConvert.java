package contest;

public class letterConvert {

	/**
	 * Rebecca Panovka
	 * ACSL Contest #4
	 * 
	 */
	public double encodeLetter(char letter)
	{
		double number= 0;
		if (letter == 'A')
		{
			number= 1;
		}
		if (letter == 'B')
		{
			number= 2;
		}
		if (letter == 'C')
		{
			number= 3;
		}
		if (letter == 'D')
		{
			number= 4;
		}
		if (letter == 'E')
		{
			number= 5;
		}
		if (letter == 'F')
		{
			number= 6;
		}
		if (letter == 'G')
		{
			number= 7;
		}
		if (letter == 'H')
		{
			number= 8;
		}
		if (letter == 'I')
		{
			number= 9;
		}
		if (letter == 'J')
		{
			number= 10;
		}
		if (letter == 'K')
		{
			number= 11;
		}
		if (letter == 'L')
		{
			number= 12;
		}
		if (letter == 'M')
		{
			number= 13;
		}
		if (letter == 'N')
		{
			number= 14;
		}
		if (letter == 'O')
		{
			number= 15;
		}
		if (letter == 'P')
		{
			number= 16;
		}
		if (letter == 'Q')
		{
			number= 17;
		}
		if (letter == 'R')
		{
			number= 18;
		}
		if (letter == 'S')
		{
			number= 19;
		}
		if (letter == 'T')
		{
			number= 20;
		}
		if (letter == 'U')
		{
			number= 21;
		}
		if (letter == 'V')
		{
			number= 22;
		}
		if (letter == 'W')
		{
			number= 23;
		}
		if (letter == 'X')
		{
			number= 24;
		}
		if (letter == 'Y')
		{
			number= 25;
		}
		if (letter == 'Z')
		{
			number= 26;
		}
		if (letter == ' ')
		{
			number= 27;
		}
		return number;	

	}
	public char encodeNumber(double number)
	{
		char letter = ' ';
		while (number>27)
		{
			number= number -27;
		}
		while (number<0)
		{
			number= number +27;
		}
		if (number == 0)
		{
			letter= ' ';
		}
		if (number == 1)
		{
			letter = 'A';
		}
		if (number == 2)
		{
			letter = 'B';
		}
		if (number == 3)
		{
			letter = 'C';
		}
		if (number == 4)
		{
			letter = 'D';
		}
		if (number == 5)
		{
			letter = 'E';
		}
		if (number == 6)
		{
			letter = 'F';
		}
		if (number == 7)
		{
			letter = 'G';
		}
		if (number == 8)
		{
			letter = 'H';
		}
		if (number == 9)
		{
			letter = 'I';
		}
		if (number == 10)
		{
			letter = 'J';
		}
		if (number == 11)
		{
			letter = 'K';
		}
		if (number == 12)
		{
			letter = 'L';
		}
		if (number == 13)
		{
			letter = 'M';
		}
		if (number == 14)
		{
			letter = 'N';
		}
		if (number == 15)
		{
			letter = 'O';
		}
		if (number == 16)
		{
			letter = 'P';
		}
		if (number == 17)
		{
			letter = 'Q';
		}
		if (number == 18)
		{
			letter = 'R';
		}
		if (number == 19)
		{
			letter = 'S';
		}
		if (number == 20)
		{
			letter = 'T';
		}
		if (number == 21)
		{
			letter = 'U';
		}
		if (number == 22)
		{
			letter = 'V';
		}
		if (number == 23)
		{
			letter = 'W';
		}
		if (number == 24)
		{
			letter = 'X';
		}
		if (number == 25)
		{
			letter = 'Y';
		}
		if (number == 26)
		{
			letter = 'Z';
		}
		
		return letter;	

	}
	
	public double invertA(double a, double b, double c, double d)
	{
		double denom = a*d - b*c;
		double num= d;
		double inverseA = num/ denom;
		return inverseA;
	}
	public double invertB(double a, double b, double c, double d)
	{
		double denom = a*d - b*c;
		double num= -1*b;
		double inverseB = num/ denom;
		return inverseB;
	}
	public double invertC(double a, double b, double c, double d)
	{
		double denom = a*d - b*c;
		double num= -1*c;
		double inverseC = num/ denom;
		return inverseC;
	}
	public double invertD(double a, double b, double c, double d)
	{
		double denom = a*d - b*c;
		double num= a;
		double inverseD = num/ denom;
		return inverseD;
	}
}
