package mancala;

public class Bowl {

	private int contains = 4;
	private int position = 0;

	public Bowl(int x, int y)
	{
		
		position = y;
		
		if ((position == 6)||(position == 13))
		{
			contains = 0;
		}
		else contains = 4;
		
	}
	public void setContains(int contains) {
		this.contains = contains;
	}

	public int getContains() {
		return contains;
	}
	
	public void add()
	{
		contains++;
	}
	
	public int dump()
	{
		int i = contains;
		contains = 0;
		return i;
	}
	
}
