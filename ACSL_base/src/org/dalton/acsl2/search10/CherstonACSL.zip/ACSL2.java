/**
 * Name: Caroline Cherston
 * School: The Dalton School
 * School Code: 9075
 */
import java.util.Scanner;

public class ACSL2 {

	public static void main(String[] args) {

		ACSL2Methods example = new ACSL2Methods(); 
		Scanner scanner = new Scanner(System.in); 
		String [] searchData = new String[9];
		searchData = scanner.nextLine().split(", ");

		for(int x=0; x<5; x++)
		{
			String input = scanner.nextLine(); 	
			example.search(input, searchData); 
		}
	}
}
