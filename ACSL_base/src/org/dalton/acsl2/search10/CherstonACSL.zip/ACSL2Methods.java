import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ACSL2Methods {

	public void ACSL2Methods()
	{

	}
	public String modify(String search)
	{
		search = search.replace('?','.'); 		
		StringBuffer searchbuf;
		searchbuf = new StringBuffer(search);
		
		for(int x = 0; x< searchbuf.length(); x++)
		{
			if(searchbuf.charAt(x) == '*')
			{
				searchbuf.insert(x,'.'); x++; 
			}
		}
		
		return searchbuf.toString();	
	}

	public void search(String search, String[] searchData)
	{
		ArrayList<String> matchup = new ArrayList<String>();
		Pattern pattern = Pattern.compile(modify(search)); 

		for(int z=0; z<searchData.length; z++)
		{
			Matcher matcher = pattern.matcher(searchData[z]); 
			boolean isMatch = matcher.matches(); 

			if(isMatch == true)
			{
				matchup.add(searchData[z]); 
			}
		}
		print(matchup); 
	}
	public void print(ArrayList<String> matches)
	{
		if(matches.size() == 0)
		{
			System.out.println("No Matches"); 
		}
		for(int z=0; z < matches.size(); z++)
		{					
			if(z == matches.size()-1)
			{
				System.out.print(matches.get(z) + "\n"); 
			}
			else if(z != matches.size())
			{
				System.out.print(matches.get(z) + ", ");
			}
		}
		matches.clear(); 
	}
}
