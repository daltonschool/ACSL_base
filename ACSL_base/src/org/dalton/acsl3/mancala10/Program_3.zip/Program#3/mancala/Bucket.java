package mancala;

public class Bucket {
	int stones = 0;
	public Bucket(int name){
		if (name == 0) stones = 0;
		else if (name == 13) stones = 0;
		else stones = 4;
	}
	public int getStones() {
		return stones;
	}
	public void setStones(int stones) {
		this.stones = stones;
	}
	public void addStone(){
		stones++;
	}
	public int takeStones(){
		int tot = stones;
		stones = 0;
		return tot;
	}
}
