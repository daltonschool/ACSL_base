
public class Oval {

	private int pennies;
	private Specialiaty flag;
	//private char index;
	
	public Oval()
	{
		pennies = 4;
		flag = flag.NONE;
	}
	public Oval(int penniesA)
	{
		//index = indexA;
		pennies = penniesA;
	}
	public Oval(int penniesA, Specialiaty flagA)
	{
		//index = indexA;
		flag = flagA;
		pennies = penniesA;
	}
	public void setPennies(int i)
	{
		pennies = i;
	}
	public void setAll(int i, Specialiaty flagA)
	{
		pennies = i;
		flag = flagA;
	}
	public int getPennies()
	{
		return pennies;
	}
	public void decrementPennies()
	{
		pennies--;
	}
	public void incrementPennies()
	{
		pennies++;
	}
}
