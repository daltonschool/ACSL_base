
public class IdMatrix {

	public int[][] matrix = new int[2][2];
	
	public IdMatrix(int ul, int ur, int ll, int lr){
		
		matrix[0][0] = ul;
		matrix[0][1] = ur;
		matrix[1][0] = ll;
		matrix[1][1] = lr;
	}
	
	public IdMatrix getInverse(){
		
		int tempfrac = 1/((matrix[0][0]*matrix[1][1]) - (matrix[0][1] * matrix[1][0]));
		
		return new IdMatrix(matrix[1][1]*tempfrac, -matrix[0][1]*tempfrac, -matrix[1][0]*tempfrac, matrix[0][0]*tempfrac);
		
	}
	
	public void checkVals(){
		
		for(int i=0;i<2;i++){
			for(int c=0;c<2;c++){
				if(matrix[i][c] > 27) matrix[i][c] = matrix[i][c]%27;
				else if(matrix[i][c] < 0 && matrix[i][c] > -27) matrix[i][c] = 27 + matrix[i][c];
			}
		}
		
	}
	
	public int[] multBy1d(int[] oned){
		int[] result = new int[2];
		
		result[0] = oned[0]*matrix[0][0] + oned[1]*matrix[0][1];
		result[1] = oned[0]*matrix[1][0] + oned[1]*matrix[1][1];
		
		return result;
	}
	
	public void print(){
		System.out.println(matrix[0][0] + " " + matrix[0][1]);
		System.out.println(matrix[1][0] + " " + matrix[1][1]);
	}
	
}
