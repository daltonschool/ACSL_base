package acsl.ACSL4;
import java.util.ArrayList;
public class Matrix {

	private ArrayList<Double> data = new ArrayList<Double>();
	
	public Matrix (String input) //creates a 2x1 matrix based on the char casts of the letters given
	{
		for (int i = 0;i<2;i++)
		{	
			try{
				if (input.charAt(i) == ' ') //from blanks spaces / spaces
				{
					data.add((double) 27);
				}
				else
				{
					data.add (((double)input.charAt(i)-64)); //remember to subtract 64
				}
			}
			catch (Exception e) //in case the array over steps it's bounds, which it never should.
			{
				System.err.print("The Matrix constructor is not working. " +
						"Make sure there are only two letters coming in.");
			}
		}
	}
	public Matrix(int x[]) //creates a matrix from an array of doubles (used to create the encoding matrix)
	{
		for (int i = 0;i<4;i++)
		{
			data.add((double) x[i]);
		}
	}
	public Matrix (double x, double y)//create a new matrix (for the 2x1 matrices)
	{
		data.add(x);
		data.add(y);
	}
	public Matrix (double a, double b, double c, double d) //create a new matrix (for the encoding matrices)
	{
		data.add(a);
		data.add(b);
		data.add(c);
		data.add(d);
	}
	public Matrix multiply(Matrix encodingMatrix) //multiplies this matrix with the encoding matrix
	{
		double x;
		double y;
		x= (data.get(0)*encodingMatrix.getA()) + (data.get(1)*encodingMatrix.getB()); //0 is x
		y = (data.get(0)*encodingMatrix.getC()) + (data.get(1)*encodingMatrix.getD()); //1 is y
		
		return new Matrix (x, y);
	}

	public Matrix getInverse() //inverts the 2x2 matrix
	{
		try{
		double denom = (data.get(0)*data.get(3)) - (data.get(1)*data.get(2)); //dat inverse denominator
		double a = (data.get(3))/denom;
		double b = (-1*data.get(1))/denom;
		double c = (-1*data.get(2))/denom;
		double d = (data.get(0))/denom;
		return new Matrix(a, b, c, d);
		}
		catch (Exception e)
		{
			System.err.print("Can't get the inverse of that matrix!");
			return null;
		}
	}
	
	public String toString() //converts a matrix back to letters with a reverse cast
	{
		String toReturn = "";
		for (int i = 0;i<2;i++)
		{
			if (myMod(Math.round(data.get(i)))==27 ||  myMod(Math.round(data.get(i)))==0)  toReturn = toReturn + ' ';
			//else if (data.get(i)<0) toReturn = toReturn + (char)(myMod(-1*Math.round(Math.abs(data.get(i))))+64);
			else toReturn = toReturn + (char)(myMod(Math.round(data.get(i)))+64);
		}
		return toReturn;
	}
	public double myMod(double double1) // calculates x mod 27, even if x is a negative number
	{
		if (double1>27) return double1%27;
		else if (double1<1) return 27-(Math.abs(double1)%27);
		else return double1;
	}
	public double getA() //returns the NW char in the matrix
	{
		return data.get(0);
	}
	public double getB() //returns the NE char in the matrix
	{
		return data.get(1);
	}
	public double getC() //returns the SW char in the matrix
	{
		return data.get(2);
	}
	public double getD() //returns the SE char in the matrix
	{
		return data.get(3);
	}
}
