/**
 * @author Danielle Midulla
 * 
 * Bugs: numbers
 * 
 */

package search_engine;
import java.util.ArrayList;
import java.util.regex.*;
public class SearchEngine {
	ArrayList<StringBuffer> in = new ArrayList<StringBuffer>();
	static int len = 0;
	public void setInput(int i, String s) {
		StringBuffer inp = new StringBuffer(s.toUpperCase());
		in.add(i, inp);
		//System.out.println(in.get(i));
		len = i+1;
	}//setInput
	public String check(String s) {
		StringBuffer ch = new StringBuffer(s.toUpperCase());
		String inp = this.toRegex(ch);
		String tot = "";
		for(int j = 0; j<len; j++){
			StringBuffer put = new StringBuffer(in.get(j));
			//System.out.println(j + put.toString());
			boolean b = Pattern.matches(inp, put.toString());
			if (b){
				tot += put.toString() + ", ";
			}
		}
		if(tot != "")tot = tot.substring(0, tot.length()-2);
		if(tot == "") System.out.println("No Match");
		return tot;
	}//check
	public String toRegex(StringBuffer s){
		String reg = "";
		/*if(s.charAt(0) != '*' && s.charAt(0) != '?'){
			reg = "^";
		}*/
		for(int i = 0; i<s.length(); i++){
			if(s.charAt(i) == '*'){
				reg = reg + "(.*)";
			}
			if(s.charAt(i) == '?'){
				reg = reg + "(.)";
			}
			else if(s.charAt(i) !='*' && s.charAt(i) != '?'){
				reg = reg +s.charAt(i);
			}
		}
		/*if(s.charAt(s.length()-1) != '*' && s.charAt(s.length()-1) != '?'){
			reg = reg + "$";
		}*/

		return reg;
	}
}//class