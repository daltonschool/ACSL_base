package matrix_endecode;

public class MatMath {

	public int lettoNum(char c){
		if (c == 'A'){
			return 1;
		}
		if (c == 'B'){
			return 2;
		}
		if (c == 'C'){
			return 3;
		}
		if (c == 'D'){
			return 4;
		}
		if (c == 'E'){
			return 5;
		}
		if (c == 'F'){
			return 6;
		}
		if (c == 'G'){
			return 7;
		}
		if (c == 'H'){
			return 8;
		}
		if (c == 'I'){
			return 9;
		}
		if (c == 'J'){
			return 10;
		}
		if (c == 'K'){
			return 11;
		}
		if (c == 'L'){
			return 12;
		}
		if (c == 'M'){
			return 13;
		}
		if (c == 'N'){
			return 14;
		}
		if (c == 'O'){
			return 15;
		}
		if (c == 'P'){
			return 16;
		}
		if (c == 'Q'){
			return 17;
		}
		if (c == 'R'){
			return 18;
		}
		if (c == 'S'){
			return 19;
		}
		if (c == 'T'){
			return 20;
		}
		if (c == 'U'){
			return 21;
		}
		if (c == 'V'){
			return 22;
		}
		if (c == 'W'){
			return 23;
		}
		if (c == 'X'){
			return 24;
		}
		if (c == 'Y'){
			return 25;
		}
		if (c == 'Z'){
			return 26;
		}
		if (c == ' '){
			return 27;
		}
		else return 0;
	}//lettoNum()
	public char numToLet(int l){
		boolean b = true;
		while(b){
			if (l == 1)return 'A';
			if (l == 2)return 'B';
			if (l == 3)return 'C';
			if (l == 4)return 'D';
			if (l == 5)return 'E';
			if (l == 6)return 'F';
			if (l == 7){
				return 'G';
			}
			if (l == 8){
				return 'H';
			}
			if (l == 9){
				return 'I';
			}
			if (l == 10){
				return 'J';
			}
			if (l == 11){
				return 'K';
			}
			if (l == 12){
				return 'L';
			}
			if (l == 13){
				return 'M';
			}
			if (l == 14){
				return 'N';
			}
			if (l == 15){
				return 'O';
			}
			if (l == 16){
				return 'P';
			}
			if (l == 17){
				return 'Q';
			}
			if (l == 18){
				return 'R';
			}
			if (l == 19){
				return 'S';
			}
			if (l == 20){
				return 'T';
			}
			if (l == 21){
				return 'U';
			}
			if (l == 22){
				return 'V';
			}
			if (l == 23){
				return 'W';
			}
			if (l == 24){
				return 'X';
			}
			if (l == 25){
				return 'Y';
			}
			if (l == 26){
				return 'Z';
			}
			if (l == 27){
				return ' ';
			}
			else if(l>27){
				l = l%27;
				continue;
			}//else if
			else if(l<0){
				l+= 135;
				continue;
			}
			else if(l == 0){
				l = 27;
				continue;
			}
		}//while
		return ' ';
	}//numtoLet()
	public String encode(String s, int[][] enc){
		String nw = "";
		if(s.length()% 2 == 1) s += " ";
		char[] c = s.toCharArray();
		int[][] mtrcs = new int[2][(int)(s.length()/2)];
		int a = 0;
		for(int i = 0; i<mtrcs[0].length; i++){
			for(int j = 0; j<2; j++){
				mtrcs[j][i] = this.lettoNum(c[a]);
				a++;
			}
		}//fill array
		if(mtrcs[1][mtrcs[0].length-1] == 0) mtrcs[1][mtrcs[0].length-1] = 27; 
		int[][] mprod = new int[2][mtrcs[0].length];
		for(int b = 0; b<s.length()/2; b++){
			mprod[0][b] = enc[0][0]*mtrcs[0][b] + enc[0][1]*mtrcs[1][b];
			mprod[1][b] = enc[1][0]*mtrcs[0][b] + enc[1][1]*mtrcs[1][b];
		}
		for(int y = 0; y<mtrcs[0].length; y++){
			for(int z = 0; z<2; z++){
				nw += this.numToLet(mprod[z][y]);
			}
		}
		return nw;
	}//encode
	public String decode(String s, int[][] enc){
		double[][]invenc = this.invMatrix(enc);
		String nw = "";
		if(s.length()% 2 == 1) s += " ";
		char[] c = s.toCharArray();
		int[][] mtrcs = new int[2][(int)(s.length()/2)];
		int a = 0;
		for(int i = 0; i<mtrcs[0].length; i++){
			for(int j = 0; j<2; j++){
				mtrcs[j][i] = this.lettoNum(c[a]);
				a++;
			}
		}//fill array
		if(mtrcs[1][mtrcs[0].length-1] == 0) mtrcs[1][mtrcs[0].length-1] = 27; 
		int[][] mprod = new int[2][mtrcs[0].length];
		for(int b = 0; b<s.length()/2; b++){
			mprod[0][b] = (int) (invenc[0][0]*mtrcs[0][b] + invenc[0][1]*mtrcs[1][b]);
			mprod[1][b] = (int) (invenc[1][0]*mtrcs[0][b] + invenc[1][1]*mtrcs[1][b]);
		}
		for(int y = 0; y<mtrcs[0].length; y++){
			for(int z = 0; z<2; z++){
				nw += this.numToLet(mprod[z][y]);
			}
		}
		return nw;
	}
	public double[][] invMatrix(int[][] matrix){
		double[][] mat = new double[matrix.length][matrix[0].length];
		for(int r = 0; r<mat.length; r++){
			for(int c = 0; c<mat[0].length; c++){
			mat[r][c] = (double) matrix[r][c];
			}
		}
		double[][] inv = new double[matrix.length][matrix[0].length];
		int d = matrix[0][0]*matrix[1][1] - matrix[0][1]*matrix[1][0];
		inv[0][0] = matrix[1][1];
		inv[1][1] = matrix[0][0];
		inv[0][1] = -1*matrix[0][1];
		inv[1][0] = -1*matrix[1][0];
		for(int r = 0; r<mat.length; r++){
			for(int c = 0; c<mat[0].length; c++){
				inv[r][c] = (inv[r][c])/d;
			}
		}
		return inv;
	}//invMatrix
}
