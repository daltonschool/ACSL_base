package matrix_endecode;
import java.util.Scanner;

public class TestClass {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		MatMath abc = new MatMath();
		String inp = "";
		String tochange[] = new String[5];
		int[][] encript = new int[2][2];
		char x;
		for (int i = 1; i<6; i++){
			System.out.print(i + ". ");
			inp = input.nextLine();
			x = inp.charAt(0);
			inp = inp.substring(3, inp.length());
			tochange = inp.split(", ");
			encript[0][0] = Integer.parseInt(tochange[1]);
			encript[0][1] = Integer.parseInt(tochange[2]);
			encript[1][0] = Integer.parseInt(tochange[3]);
			encript[1][1] = Integer.parseInt(tochange[4]);
			if(x == 'E'){
				System.out.println(i + ". " + abc.encode(tochange[0], encript));
			}
			if(x == 'D'){
				System.out.println(i + ". " + abc.decode(tochange[0], encript));
			}
		}//for

	}
}
