import java.util.Scanner;

class main{

    public static void main(String[] args){

	Board test = new Board();
	test.initialize();
	Scanner in = new Scanner(System.in);
	String newline = "";
	int i = 0;
	for(i=0;i<5;i++){
	    newline = in.nextLine();
	    String[] inputs = new String[2];
	    inputs = newline.split(", ");
	    if(i%2 == 0){
		test.moveA(Integer.parseInt(inputs[0]));
	    }
	    else{
		test.moveB(Integer.parseInt(inputs[0]));
	    }
	    if(inputs[1].contains("A")){
		System.out.println(test.getA());
	    }
	    else if(inputs[1].contains("B")){
		System.out.println(test.getB());
	    }
	    else{
		System.out.println(test.getSpace(Integer.parseInt(inputs[1])));
	    }
	}
    }


}