
public enum Specialiaty {
NONE, A, B
}
