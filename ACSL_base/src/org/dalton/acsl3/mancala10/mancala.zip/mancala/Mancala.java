/**Sam Buck
 * The Dalton School
 * Code:9075 
 */


package mancala;

import java.util.Scanner;

public class Mancala {

	private static final boolean DEBUG = false;
	private static final boolean DEBUG_VIEW = false;
	private static final boolean DEBUG_PARSE = false;
	private static Bowl[] board = new Bowl[14];
	private static char player = 'B';

	public static void main(String[] args)
	{

		instantiate();


		Scanner s = new Scanner(System.in);
		while(true){
			if (DEBUG_VIEW) System.out.println("NEW TURN");
			player = change(player);
			StringBuffer sb = new StringBuffer(s.nextLine());

			String n;
			String d;

			String ss = sb.toString();
			String[] sa = ss.split(", ");
			n = sa[0];
			d = sa[1];

			int pickABowl = 0;		
			if (sa[0].length() == 1) pickABowl = renumeral(sa[0].toCharArray()[0]);		
			else{
				if (sa[0].equals("10")) pickABowl = 10;
				if (sa[0].equals("11")) pickABowl = 11;
				if (sa[0].equals("12")) pickABowl = 12;

			}


			int GetOutputFrom = 0;		
			if (sa[1].length() == 1) GetOutputFrom = renumeral(sa[1].toCharArray()[0]);		
			else{
				if (sa[1].equals("10")) GetOutputFrom = 10;
				if (sa[1].equals("11")) GetOutputFrom = 11;
				if (sa[1].equals("12")) GetOutputFrom = 12;
			}

			if (DEBUG_PARSE) System.out.println("Bagel" + pickABowl);
			if (DEBUG_PARSE) System.out.println("Coffee" + GetOutputFrom);
			begin(pickABowl);
			System.out.println(board[GetOutputFrom].getContains());

		}



	}

	private static char change(char c) {
		if (c == 'A') return 'B';
		if (c == 'B') return 'A';
		else return ' ';
		
	}

	private static void instantiate() {

		for (int i = 0; i < 14; i++)
		{
			board[i] = new Bowl(4, i);
		}

	}

	private static int renumeral(char x) {
		switch(x){
		case '1': return 0;
		case '2': return 1;
		case '3': return 2;
		case '4': return 3;
		case '5': return 4;
		case '6': return 5;
		case 'A': return 6;
		case '7': return 7;
		case '8': return 8;
		case '9': return 9;
		case 'B': return 13;



		}
		return x;
	}







	@SuppressWarnings("unused")
	/**Variables:
	 * int hand = how many beads in hand
	 * int i = bowl I'm over
	 * int h = bowl I'm over. Holds past for loop
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	private static void begin(int start)
	{
		int hand = 0;
		hand = board[start].dump();
		if (DEBUG) System.out.println(start);
		boolean flag = false;
		int h = start;
		boolean first = true;
		while (!flag)
		{
			if (DEBUG_VIEW) System.out.println("Trippy");

			if (DEBUG) System.out.println("MAINLOOP" + h);

			if ((!first)&&((h != 6)||(h != 13)))hand = board[h].dump();
			else if ((h == 6)||(h == 13)) break;


			h++;
			for (int i = h; hand > 0; i = add(i))
			{

				if (DEBUG) System.out.println("Place " + i + " Inhand: " + hand + "InBelow " + board[i].getContains());
				
				if (!enemyMancala(i)){
					h = i;
					board[i].add();
					hand--;
				}
				
				if (DEBUG_VIEW)
				{
					System.out.println("NEWMAP JUST DUMPED INTO " + h + ", HOLDING " + hand);
					System.out.println("   " + board[6].getContains());
					System.out.println(board[7].getContains() + " , " + board[5].getContains());
					System.out.println(board[8].getContains() + " , " + board[4].getContains());
					System.out.println(board[9].getContains() + " , " + board[3].getContains());
					System.out.println(board[10].getContains() + " , " + board[2].getContains());
					System.out.println(board[11].getContains() + " , " + board[1].getContains());
					System.out.println(board[12].getContains() + " , " + board[0].getContains());
					System.out.println("   " + board[13].getContains());
				}
				
				if (DEBUG) System.out.println("2Place " + i + " Inhand: " + hand + "InBelow " + board[i].getContains());
			}
			if (end(h)) flag = true;
			first = false;
		}
	}

	private static boolean end(int h)
	{
		if (board[h].getContains() == 4) return true;
		if (board[h].getContains() == 1) return true;
		if (h == 6) return true;
		if (h == 13) return true;
		
		
		
		
		return false;
	}

	private static boolean enemyMancala(int i) {
		char a = player;
		if ((a == 'A')&&(i == 13)) return true;
		if ((a == 'B')&&(i == 6)) return true;
		return false;
	}

	private static int add(int i) {
		if (i == 13)
		{
			return 0;
		}
		else return i + 1;
	}
}
