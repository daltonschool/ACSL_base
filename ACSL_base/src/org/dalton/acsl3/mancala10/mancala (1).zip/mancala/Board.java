class Board{

    int[] spaces = new int[13];
    int a = 0;
    int b = 0;

    public void initialize(){
	int i = 0;
	for(i=1;i<13;i++){
	    spaces[i] = 4;
	}
    }

    public void incrementA(){
	a++;
    }

    public void incrementB(){
	b++;
    }

    public int getA(){
	return a;
    }

    public int getB(){
	return b;
    }

    public int getSpace(int space){
	return spaces[space];
    }

    public void setSpace(int space, int val){
	spaces[space] = val;
    }

    public void print(){
	int i = 0;
	for(i=1;i<13;i++){
	    System.out.println(i + ": " + spaces[i]);
	}
	System.out.println("A: " + a);
	System.out.println("B: " + b);
    }

    public void moveA(int space){
	boolean inc_a = false;
	//System.out.println("MOVING A");
	int temp = this.getSpace(space);
	//System.out.println("temp is " + temp);
	if(space == 12){
	    this.setSpace(space, 0);
	    space = 0;
	}
	this.setSpace(space, 0);
	space++;
	while(temp > 0){
	    inc_a = false;
	    if(temp >= 1 && space-1 == 6){
		this.incrementA();
		inc_a = true;
		temp--;
	    }
	    if(temp == 1){
		inc_a = false;
	    }
	    temp--;
	    if(temp >= 0){
		this.setSpace(space, this.getSpace(space) + 1);
	    }
	    if(temp > 0){
		space++;
	    }
	    if(space >= 13){
		space = space - 12;;
	    }
	}
	//this.print();
	//System.out.println("current space is " + space + ". space is equal to " + this.getSpace(space));
	//System.out.println("inc_a = " + inc_a);
	if(this.getSpace(space) != 4 && this.getSpace(space) != 1 && !inc_a){
	    this.moveA(space);
	}
    }

    public void moveB(int space){
	boolean inc_b = false;
	//System.out.println("MOVING B");
	int temp = this.getSpace(space);
        //System.out.println("temp is " + temp);
      	if(space == 12){
	    this.setSpace(space, 0);
	    space = 0;
	}
	this.setSpace(space, 0);
        space++;
        while(temp > 0){
	    inc_b = false;
            if(temp >= 1 && space-1 == 0){
		this.incrementB();
		//System.out.println("incrementing b to " + b);
                inc_b = true;
		temp--;
            }
	    if(temp == 1){
		inc_b = false;
	    }
            temp--;
	    //System.out.println("space is " + space + ". temp is " + temp);
            if(temp >= 0){
		//System.out.println("incrementing space " + space + " to " + (this.getSpace(space)+1));
                this.setSpace(space, this.getSpace(space) + 1);
            }
	    if(temp > 0){
		space++;
	    }
            if(space >= 13){
                space = space - 12;
            }
        }
        //this.print();
        //System.out.println("current space is " + space + ". space is equal to " + this.getSpace(space));
	//System.out.println("inc_b = " + inc_b);
        if(this.getSpace(space) != 4 && this.getSpace(space) != 1 && !inc_b){
            this.moveB(space);
        }
    }


}

